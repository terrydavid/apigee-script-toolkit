 
var har = context.getVariable("thisMsg.hash_rsp");
if (typeof (har) !== "undefined" && har !== null && har !== "") {
    var hash = har.substr(0, har.indexOf(" {"));
    var resp = har.substr(har.indexOf(" {")+1);

    context.setVariable('thisMsg.client_hash', hash);
    context.setVariable('request.content', resp);

    var rspo = JSON.parse(resp);
    var token = rspo.access_token;
    context.setVariable('thisMsg.access_token', token);
    
    var jwt = rspo.id_token;
    context.setVariable('thisMsg.id_token', jwt);
}

if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
        print ("\n deserTkn: " + context.getVariable("proxy.pathsuffix")
    + "\nhash: " + hash
    + "\nresp: " + resp
    + "\ntoken: " + token
    + "\njwt: " + jwt
    + "\n");
    