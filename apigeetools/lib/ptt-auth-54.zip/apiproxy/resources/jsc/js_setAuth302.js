// Capture and store the inbound params, and replace with our own
context.setVariable("request.queryparam.response_type", "code");

var client_id = context.getVariable("thisMsg.client_id");
if ( typeof (client_id) !== "undefined" && client_id !== null && client_id !== "") {
    var client_hash = context.getVariable("thisMsg.client_hash");
    context.setVariable("request.queryparam.client_id", client_id);
    context.setVariable("request.queryparam.state", client_id);
    if ( typeof (client_hash) !== "undefined" && client_hash !== null && client_hash !== "")
        context.setVariable("request.queryparam.state", client_hash);
}
var client_id = context.getVariable("verifyapikey.oa2_verifyAPIKey.client_id1");

var redirect_uris = context.getVariable("verifyapikey.oa2_verifyAPIKey.redirection_uris");
context.setVariable("request.queryparam.redirect_uri", redirect_uris);

var iDPscope = context.getVariable("request.queryparam.scope");
context.setVariable("verifyapikey.oa2_verifyAPIKey.oauth_scope", iDPscope);

var gscope = "openid profile email";
context.setVariable("request.queryparam.scope", gscope);

var idpAuthPath = context.getVariable("verifyapikey.oa2_verifyAPIKey.authorize_path");
if ( typeof (idpAuthPath) !== "undefined" && idpAuthPath !== null && idpAuthPath !== "") {
    if ( idpAuthPath.indexOf("://") != 5) idpAuthPath = "https://" + idpAuthPath;
    context.setVariable("thisMsg.idpAuthPath", idpAuthPath);
}

var apikey = context.getVariable("thisMsg.client_hash");
var a_code = context.getVariable("thisMsg.auth_code");
if ( typeof (a_code) !== "undefined" && a_code !== null && a_code !== "" )
    context.setVariable("response.header.Set-Cookie", "ac=" + a_code + ";" + "ak=" + apikey);

context.setVariable("response.status.code", "302");

var loc = idpAuthPath 
        + "?client_id=" + client_id 
        + "&response_type=code"
        + "&redirect_uri=" + redirect_uris 
        + "&scope=" + gscope
        + "&state=" + apikey;

context.setVariable("response.header.Location", loc);

if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
        print ("\n[setAuth302]: " + context.getVariable("proxy.pathsuffix")
    + "\nclient_id= " + client_id
    + "\ncstate= " + client_hash
    + "\nredirect_uri= " + redirect_uris
    + "\niDPscope= " + iDPscope
    + "\ngscope= " + gscope
    + "\nidpAuthPath= " + idpAuthPath
    + "\n\tLocation= " + loc 
    + "\n\n"); 


