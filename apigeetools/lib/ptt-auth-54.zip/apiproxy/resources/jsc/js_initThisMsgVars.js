// client_id, response_type, & [redir] need to be in queryparams (dfault for auth code gen)

context.setVariable("thisMsg.DEBUG", "WARN");

var skeyVal = '';
function rebuild (s) {
    var newstate = decodeURIComponent(s);

    // break down the "state" subvar into arrays for re-construction
    var starr = newstate.split("&");
    var state = starr[0];
    var skey = starr[1];
    var id = starr[2];
    
    var wantsarr = state.split("?");
    var uri = wantsarr[0];
    var wants = wantsarr[1];

    if ( typeof (skey) !== "undefined" && skey !== null && skey !== "") {
        skeyVal = skey.substr(skey.indexOf("=")+1);

        state = uri + "?" + encodeURI(wants) + "&sesskey=" + skeyVal + "&id=" + id.substr(id.indexOf("=")+1) ;
        
        context.setVariable("request.queryparam.state", client_id);
        context.setVariable("thisMsg.wantState", state);
        context.setVariable("thisMsg.sesskey", skeyVal);
    } 
    return s;
}

var client_id = context.getVariable("thisMsg.client_id");
// If we -dont have a client_id in the Auth Header...
if ( typeof (client_id) === "undefined" || client_id === null || client_id === "") {
    // ...Is the cid in a queryparam ?
    client_id = context.getVariable("request.queryparam.client_id");
    if ( typeof (client_id) === "undefined" || client_id === null || client_id === "") {
        // ... Was not in qp, try fp
        client_id = context.getVariable("request.formparam.client_id");
        if ( typeof (client_id) === "undefined" || client_id === null || client_id === "") {
            // last chance - the client_id could be in the state param
            client_id = decodeURIComponent(context.getVariable("request.queryparam.state"));
            if ( typeof (client_id) === "undefined" || client_id === null || client_id === "") {
                // No Client ID available, so move on
                print ("\nInit: No client_id found");
            }
        }
    }
}

var client_secret = context.getVariable("thisMsg.client_secret");
// If we -dont have a client_secret in the Auth Header...
if ( typeof (client_secret) === "undefined" || client_secret === null || client_secret === "") {
    // ...Is the csecret in a formparam ?
    client_secret = context.getVariable("request.queryparam.client_secret");
    if ( typeof (client_secret) === "undefined" || client_secret === null || client_secret === "") {
        client_secret = context.getVariable("request.formparam.client_secret");
        // ... Was not in qp, try fp
        if ( typeof (client_id) === "undefined" || client_id === null || client_id === "") {
            print ("\nInit: No client secret found");
        }    
    }
    context.setVariable("thisMsg.client_secret", client_secret);
} 

var client_hash = client_id;
if ( typeof (client_id) !== "undefined" && client_id !== null && client_id !== "") {
    if (client_id.indexOf(":") > 0) {
        skeyVal = client_id.substr(client_id.indexOf(":")+1);
        if ( typeof (skeyVal) !== "undefined" && skeyVal !== null && skeyVal !== "") {
            client_id = client_id.substr(0, (client_id.indexOf(":")));
        } else 
            skeyVal = Math.random().toString(36);
            // .replace(/[^a-z0-9]+/g, '').substr(0, 5).toUpperCase();
    } else
        skeyVal = Math.random().toString(36);
    client_hash = client_id + ":" + skeyVal;
    context.setVariable("thisMsg.client_id", client_id);
}
context.setVariable("thisMsg.client_hash", encodeURIComponent(client_hash));

var client_ip = context.getVariable("client.ip");
var testip = context.getVariable("request.queryparam.testip");
if ( typeof (testip) !== "undefined" && testip !== null && testip !== "")
    client_ip = testip;
context.setVariable("thisMsg.client_ip", client_ip);

// LMS "state" variable stuff (re-de-en-code the LMS "state" variable due to inconsistent encoding and Apigee impacts)
var client_state = client_ip;
var oldstate = context.getVariable("request.queryparam.state"); //  && (oldstate.indexOf("wantsurl") >= 0) 
if ( typeof (oldstate) !== "undefined" && oldstate !== null && oldstate !== "" ) {
    oldstate = rebuild(oldstate);
    client_state = client_state + ' ' + oldstate;
    
} else {
    print("No queryparam.state");
    client_state = client_state + ' NOSTATE';
    // client_state = client_state + ' ' + client_id;
}

var authhdr = context.getVariable("request.header.authorization");
if ( typeof (authhdr) !== "undefined" && authhdr !== null && authhdr !== "" ) {
    context.setVariable("thisMsg.auth_hdr", authhdr);
    var jwtat = authhdr.substr(authhdr.indexOf("Bearer ")+7);
    context.setVariable("thisMsg.id_token", jwtat);
}

var becallbck = context.getVariable("request.queryparam.redirect_uri");
if ( typeof (becallbck) === "undefined" || becallbck === null || becallbck === "" )
    becallbck = context.getVariable("request.formparam.redirect_uri");
if ( typeof (becallbck) !== "undefined" && becallbck !== null && becallbck !== "" ) {
    client_state = client_state + ' ' + becallbck;
    context.setVariable('thisMsg.tgt_redir', becallbck);
}

var cscopes = context.getVariable("request.queryparam.scope");
if ( typeof (cscopes) !== "undefined" && cscopes !== null && cscopes !== "" ) {
    context.setVariable('thisMsg.client_scopes', cscopes);
}
context.setVariable("thisMsg.client_state", client_state);

var cookieACode = "NOCOOKIE", cookieAKode = "NOKOOKIE", codeACookie = context.getVariable("request.header.cookie");
if ( typeof (codeACookie) !== "undefined" && codeACookie !== null && codeACookie !== "" ) {
    cookieACode = codeACookie.substr(codeACookie.indexOf("ac=")+3), codeACookie.indexOf(";")-1 ;
    if ( typeof (cookieACode) !== "undefined" && cookieACode !== null && cookieACode !== "" ) {
        context.setVariable("thisMsg.auth_code", cookieACode);
        // client_state = client_state + ' ' + cookieACode;
    }
    // cookieAKode = codeAKookie.substr(codeAKookie.indexOf("ak=")+3), codeACookie.indexOf(";")-1 ;
    // if ( typeof (cookieAKode) !== "undefined" && cookieAKode !== null && cookieAKode !== "" ) {
    //     context.setVariable("thisMsg.client_hash", cookieAKode);
    //     // client_state = client_state + ' ' + cookieAKode;
    // }
}

var a_code = context.getVariable("request.queryparam.code");
if (typeof (a_code) === "undefined" || a_code === null || a_code === "")
    a_code = context.getVariable("request.formparam.code");

if (typeof (a_code) !== "undefined" && a_code !== null && a_code !== "") {
    context.setVariable("thisMsg.auth_code", a_code);
    client_state = client_state + ' ' + a_code;
}

// if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
        print ("\nInit: " + context.getVariable("proxy.pathsuffix")
    + "\nclient_id= " + client_id 
    + "\na_code= " + a_code 
    + "\nredirect= " + becallbck 
    + "\noldstate= " + oldstate 
    + "\nskeyVal= " + skeyVal 
    + "\nclient_state= " + client_state 
    + "\nclient_hash= " + client_hash 
    + "\n"); 


