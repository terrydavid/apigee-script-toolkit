context.setVariable("target.copy.queryparams", "false");
context.setVariable("target.copy.pathsuffix", "false");

var auth = context.getVariable("request.header.Authorization");

// if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
//         print ("\n[tgt_copyOff]: " + context.getVariable("proxy.pathsuffix")
//     + auth
//     + " ]\n");
