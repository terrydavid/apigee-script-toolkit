// Use JSON object template
var resp = context.getVariable ("myResponse.content");
var rsp = JSON.parse(resp);
var groups = "";
var i,j=0;

if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
        print ("\n[ev_getGroupNames]: " + context.getVariable("proxy.pathsuffix")
    + "\nExtractingGroups.content(resp)=\n" + resp
    + "\n");

if (typeof (rsp) !== "undefined" && rsp !== null && rsp !=="") {
    if (typeof (rsp.error) !== "undefined" && rsp.error !== null && rsp.error !=="") {
        print ("Error in response: " + context.getVariable("response.header.status_code"));
        
    } else if (typeof (rsp.groups) !== "undefined" && rsp.groups !== null && rsp.groups !=="") {
        try {
            for (i=(rsp.groups).length;i--;i>0) {
                j = rsp.groups[i].name.indexOf("ptt-user");
                print ("\ngroup["+i+"]=" + rsp.groups[i].name + "; index=" + j);
                
                if (-1 !== j) {
                    if (groups !== "") groups += ",";
                    groups += rsp.groups[i].name.substr(13);
                }
            }
        } catch (e) {
            fault("Still trying to parse rsp.goups");
        }
    }
}

if (groups === "") {
    // throw ("\nNo Groups");
    groups = "student,instructor";
    print ("\nNo Groups");
    // groups = "student";
}
print ("\n\nGroups= " + groups);

context.setVariable('thisMsg.groups', groups);
context.setVariable('response.header.x-id_token', context.getVariable("gcp.id_token"));
context.setVariable('response.content', resp);
// context.setVariable('response.content', JSON.stringify(rsp));

if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
        print ("\n ev_getGroupNames: " + context.getVariable("proxy.pathsuffix")
    + "\nAuthorization: " + context.getVariable("request.header.authorization")
    + "\n\nGroups= " + groups
    + "\n");
