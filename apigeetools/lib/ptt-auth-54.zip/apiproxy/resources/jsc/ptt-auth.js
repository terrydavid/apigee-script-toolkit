var swagger = {
  "openapi": "3.0.0",
  "info": {
    "title": "PTT-AUTH API",
    "description": "DIUPTT activities are part of the US Federal government, and are restricted. All rights reserved. [SelfLink](http://api-test.api.diuptt.io/v1/auth).",
    "version": "0.1.1"
  },
  "servers": [
    {
      "url": "https://api-test.api.diuptt.io/v1",
      "description": "Apigee \"api-test\" API Vendor Dev & Test environment"
    },
    {
      "url": "https://ddev-stage.api.diuptt.io/v1",
      "description": "Apigee \"test\" API Staging & Integration Test environment"
    },
    {
      "url": "https://ddev-prod.api.diuptt.io/v1",
      "description": "Apigee \"prod\" DIUPTT Production environment"
    },
    {
      "url": "https://api-dev.api.diuptt.io/v1",
      "description": "Apigee \"api-dev\" API development environment"
    }
  ],
  "tags": [
    {
      "name": "OAuth2",
      "description": "Requests related to retrieving OAuth2 Tokens."
    }
  ],
  "paths": {
    "/auth/oauth/authorize": {
      "get": {
        "tags": [
          "Authorization"
        ],
        "summary": "Authorization call for Oauth2 auth_code grant",
        "description": "\"?response_type=code&state={stateOfTheUserApplication-returnedUnchanged}&client_id={theCllientID/ApplicationKey}&scope={spaceSeparatedListofResourceScopes}&redirect_uri={urlEncodedURLofTheCallbackLocation}\"",
        "parameters": [
          {
            "in": "header",
            "name": "Authorization",
            "schema": {
              "type": "string"
            },
            "description": "base64 encoded client ID & Secret 'base64encode(<clientID:clientSecret>)' (aka \"application key\")",
            "required": true
          },
          {
            "in": "query",
            "name": "response_code",
            "schema": {
              "type": "string"
            },
            "description": "= \"code\"",
            "required": true
          },
          {
            "in": "query",
            "name": "redirect_uri",
            "schema": {
              "type": "string"
            },
            "description": "Redirect URI for the application key / client id",
            "required": true
          },
          {
            "in": "query",
            "name": "client_id",
            "schema": {
              "type": "string"
            },
            "description": "Redirect URI for the application key / client id",
            "required": true
          },
          {
            "in": "query",
            "name": "state",
            "schema": {
              "type": "string"
            },
            "description": "Optional caller state to be returned",
            "required": false
          },
          {
            "in": "query",
            "name": "scope",
            "schema": {
              "type": "string"
            },
            "description": "Any optional Oauth2 scopes needed for access to subsequent API calls",
            "required": false
          }
        ],
        "responses": {
          "302": {
            "description": "Redirect auth call to 3rd party IDP ('string' as 'Location' header value)",
            "content": {
              "text/plain": {
                "schema": {
                  "type": "string"
                },
                "example": "Location: <big_long_redirect_string_browser_should_call_next>"
              }
            }
          }
        }
      }
    },
    "/auth/oauth/token": {
      "post": {
        "tags": [
          "Authorization"
        ],
        "summary": "Retrieve Token call for Oauth2 auth_code grant",
        "description": "This token will be the PTT standard JWT",
        "parameters": [
          {
            "in": "header",
            "name": "Authorization",
            "schema": {
              "type": "string"
            },
            "description": "base64 encoded Client ID & Secret ['Basic' 'base64encode(<clientID:clientSecret>)'] (aka \"application key\")",
            "required": true
          }
        ],
        "requestBody": {
          "content": {
            "text/plain": {
              "schema": {
                "$ref": "#/components/schemas/tokenForm"
              },
              "examples": {
                "TokenRequest": {
                  "description": "Form parameters for 'token' call ---  \"?grant_type=authorization_code&code={authCodeReceivedFromAuthorizationRequest}&redirect_uri={callbackURLforThisApplication}&client_id={theCllientID/ApplicationKey}\""
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Token retrieved",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "items": {
                    "type": "string"
                  }
                }
              }
            }
          },
          "400": {
            "description": "40X Errors in variables sent."
          },
          "500": {
            "description": "50X Errors from server processing."
          }
        }
      }
    },
    "/auth/oauth/cctoken": {
      "get": {
        "tags": [
          "Authorization"
        ],
        "summary": "Authorization call for Oauth2 client credentials grant",
        "description": "Optional extended description",
        "parameters": [
          {
            "in": "header",
            "name": "Authorization",
            "schema": {
              "type": "string"
            },
            "description": "base64 encoded Client ID & Secret ['Basic' 'base64encode(<clientID:clientSecret>)'] (aka \"application key\")"
          },
          {
            "in": "query",
            "name": "grant_type",
            "schema": {
              "type": "string"
            },
            "description": "= \"client_credentials\"",
            "required": true
          }
        ],
        "responses": {
          "200": {
            "description": "Return Client Credentials access token",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "items": {
                    "type": "string"
                  }
                }
              }
            }
          }
        }
      }
    }
  },
  "components": {
    "schemas": {
      "ism": {
        "title": "Classification",
        "type": "object",
        "properties": {
          "classification": {
            "description": "Classification of data. U = unclassified",
            "type": "string",
            "example": "U"
          },
          "ownerProducer": {
            "description": "Owner of the data",
            "type": "array",
            "items": {
              "type": "string"
            },
            "example": [
              "USA"
            ]
          },
          "version": {
            "description": "Version of JSON-SMS",
            "type": "integer",
            "example": 1
          }
        }
      },
      "meta": {
        "title": "Metadata",
        "properties": {
          "date": {
            "description": "Date and time of request in UTC",
            "type": "string",
            "example": "2020-12-21-T19:57:12Z"
          }
        }
      },
      "defaultPostResponse": {
        "title": "Default Post Response (TBD - Not Used)",
        "type": "object",
        "properties": {
          "data": {
            "type": "object",
            "properties": {
              "request_sent_to_sim": {
                "type": "object",
                "example": 1,
                "description": "If the request was sent to the sim"
              }
            }
          },
          "ism": {
            "$ref": "#/components/schemas/ism"
          },
          "meta": {
            "$ref": "#/components/schemas/meta"
          }
        }
      },
      "tokenForm": {
        "title": "url-encoded form parameters for auth Token request",
        "type": "object",
        "example": "?grant_type=authorization_code&code={authCodeReceivedFromAuthorizationRequest}&redirect_uri={callbackURLforThisApplication}&client_id={theCllientID/ApplicationKey}"
      }
    }
  }
}