var ip_state = context.getVariable("thisMsg.client_state");

if ( typeof(ip_state) !== "undefined" && ip_state !== null && ip_state !== "") {
    var arr = ip_state.split(" ");
    var wants = encodeURIComponent(arr[1]);

    var redir = arr[2];
    // if ( typeof(redir) === "undefined" || redir === null || redir === "")
        redir = context.getVariable("verifyapikey.oa2_verifyAPIKey.redirection_uris");

    var code = arr[3];
    if ( typeof(code) === "undefined" || code === null || code === "")
        code = context.getVariable("request.queryparam.code");

    var token = arr[4];
    if ( typeof(token) === "undefined" || token === null && token === "") 
        token = context.getVariable("thisMsg.access_token");

    context.setVariable("thisMsg.client_ip", arr[0]);
    context.setVariable("thisMsg.wantState", wants);
    context.setVariable("thisMsg.tgt_redir", redir);
    context.setVariable("thisMsg.auth_code", code);
    context.setVariable("thisMsg.access_token", token);
    context.setVariable("thisMsg.x-diuptt-jwt", token);
    context.setVariable("request.queryparam.scope", "openid profile email");

    if ( typeof(code) !== "undefined" && code !== null && code !== "" && token === "")
        context.setVariable("thisMsg.client_state", ip_state + " " + code + " " + token);
        
    

    if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
            print ("\n[mungeKVMCIP]: " + context.getVariable("proxy.pathsuffix")
        + "\nclient_ip= " + arr[0]
        + "\nwantState= " + wants
        + "\ntgt_redir= " + redir
        + "\nauth_code= " + code
        + "\naccess_token= " + token
        + "\nclient_state= " + context.getVariable("thisMsg.client_state")
        + "\n");
}