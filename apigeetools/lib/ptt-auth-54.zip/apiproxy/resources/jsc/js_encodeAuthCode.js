
context.setVariable("thisMsg.auth_code", encodeURIComponent(context.getVariable("request.formparam.code")));
