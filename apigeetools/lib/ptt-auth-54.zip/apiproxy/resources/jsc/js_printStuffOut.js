var req = context.getVariable("request.content");
var res = context.getVariable("response.content");

var rquri = context.getVariable("servicecallout.requesturi");
var reqc = context.getVariable("thisMsg.myRequest.content");
var reqa = context.getVariable("thisMsg.authorization");

var idtoken = context.getVariable("thisMsg.id_token");
var atoken = context.getVariable("thisMsg.access_token");

var tgthst = context.getVariable("servicecallout.sc_getAccToken.target.url");
var resp = context.getVariable("thisMsg.myResponse.content");
var respcode = context.getVariable("thisMsg.myResponse.status.code");

var tgthst2 = context.getVariable("servicecallout.sc_pushJWT.target.url");
var resp2 = context.getVariable("thisMsg.myResponse2.content");
var respcode2 = context.getVariable("thisMsg.myResponse2.status.code");

var auth = context.getVariable("thisMsg.myRequest.header.authorization");
var fcid = context.getVariable("request.formparam.client_id");
var tcid = context.getVariable("thisMsg.client_id");
var tcst = context.getVariable("thisMsg.client_state");

var thism = context.getVariable("thisMsg");

var rsphdrs = context.getVariable("response.headers.names");
var reqhdrs = context.getVariable("resquest.headers.names");

if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
        print ("\n[PrintStuffOut]: " + context.getVariable("proxy.pathsuffix")
    + "\n\trequest= " + req  
    + "\n\tresponse= " + res
    + "\n\tAuth= " + auth  
    // + "\n\tform-cid= " + fcid  
    // + "\n\tthis-cid= " + tcid
    + "\n\tresponse.header.names= " + rsphdrs
    + "\n\trequest.header.names= " + reqhdrs
    + "\n\tthisMsg.client_state= " + tcst
    // + "\n\tthisMsg= " + thism

    + "\n\tsc_requesturi= " + rquri  
    + "\n\tsc_hdr_auth= " + reqa  

    + "\n\t1cs_req_content= " + reqc 

    + "\n\t1sc_target.url= " + tgthst  
    + "\n\t1cs_resp_content= " + resp 
    + "\n\t1cs_resp_code= " + respcode 

    + "\n\n\t2sc_target.url= " + tgthst2  
    // + "\n\t2cs_auth_token= " + token 
    + "\n\t2cs_resp_content= " + resp2 
    + "\n\t2cs_resp_code= " + respcode2 

    // // + "\n\nthisMsg= " + JSON.parse(context.getVariable("thisMsg")) 
    + "\n\nthisMsg= " + context.getVariable("thisMsg") 
    + "\n\nthisMsg.id_token= " + context.getVariable("thisMsg.id_token") 
    + "\n\nthisMsg.accesstoken= " + context.getVariable("thisMsg.access_token") 
    + "\n\nthisMsg.client_state= " + context.getVariable("thisMsg.client_state") 
    + "\n");

