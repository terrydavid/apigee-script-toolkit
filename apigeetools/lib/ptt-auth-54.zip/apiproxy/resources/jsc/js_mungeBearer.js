// Use JSON object template
var resp = context.getVariable ("response.content");
if ( typeof (resp) !== "undefined" && resp !== null && resp !== '' ) {    
    var rsp = JSON.parse(resp);
    rsp.token_type = "Bearer";
    context.setVariable('response.content', JSON.stringify(rsp));
}

var token = context.getVariable("thisMsg.access_token");
if ( typeof (token) === "undefined" || token === null || token === '' ) {    
    token = context.getVariable("apigee.access_token");
    context.setVariable("thisMsg.access_token", token);
}