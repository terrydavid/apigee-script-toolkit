// // var token = encodeURIComponent(context.getVariable("response.header.x-diuptt-jwt"));
// var jwt = encodeURIComponent(context.getVariable("thisMsg.X-DIUPTT-JWT"));
// context.setVariable("thisMsg.access_token", jwt);

// var hash = context.getVariable("thisMsg.client_hash");
// var tkn_rsp = JSON.parse(context.getVariable("oauthv2accesstoken.oa2_setClientIP.tkn_rsp"));
// tkn_rsp.access_token = jwt;
// var newTrsp = JSON.stringify(tkn_rsp);
// hash = hash + " " + newTrsp;
// context.setVariable("thisMsg.hash_rsp", hash);

// var code = encodeURIComponent(context.getVariable("request.queryparam.code"));
// var state = context.getVariable("thisMsg.client_state");
// if ( typeof (code) !== "undefined" && code !== null && code !== "" ) {
//     if ( typeof (token) !== "undefined" && token !== null && token !== "" )
//         state = state + " " + code + " " + token;
//     else 
//         state = state + " " + code;
//     context.setVariable("thisMsg.code", code);
// }
// context.setVariable("thisMsg.client_state", state);

// if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
//         print("\n[updateKVM]: " + context.getVariable("proxy.pathsuffix")
//     + "\ntoken/jwt= " + jwt
//     // + "\njwt= " + jwt
//     + "\nclient_state= " + state
//     + "\nclient_hash_rsp= " + hash
//     + "\n");


// var token = encodeURIComponent(context.getVariable("response.header.x-diuptt-jwt"));
var token = encodeURIComponent(context.getVariable("thisMsg.X-DIUPTT-JWT"));
context.setVariable("thisMsg.access_token", token);

var hash = context.getVariable("thisMsg.client_hash");
var jwt = JSON.parse(context.getVariable("oauthv2accesstoken.oa2_setClientIP.tkn_rsp"));
jwt.apii = token;
var jot = JSON.stringify(jwt);
hash = hash + " " + jot;
// hash = hash + " " + token;

var code = encodeURIComponent(context.getVariable("request.queryparam.code"));
context.setVariable("thisMsg.code", code);
var state = context.getVariable("thisMsg.client_state");
if (( typeof (code) !== "undefined" && code !== null && code !== "" ) && 
        ( typeof (token) !== "undefined" && token !== null && token !== "" ))
    state = state + " " + code + " " + token;
else 
    state = state + " " + code;
context.setVariable("thisMsg.client_state", state);

context.setVariable("thisMsg.hash_rsp", hash);

// if ( context.getVariable("thisMsg.DEBUG") === "DEBUG" ) 
        print("\n[updateKVM]: " + context.getVariable("proxy.pathsuffix")
    + "\ntoken= " + token
    + "\njwt= " + jot
    + "\nclient_state= " + state
    + "\nclient_hash_rsp= " + hash
    + "\n");
