var swagstr = JSON.stringify(swagger)
print ('\nSwagger = ' + swagstr);

Object.keys(swagger).forEach(function(key){
  context.setVariable('settings_' + key, swagger[key]);
  print ("Key: " + key + " Value=" + JSON.stringify(swagger[key]));
});

context.setVariable('thisMsg.swagger', swagstr);