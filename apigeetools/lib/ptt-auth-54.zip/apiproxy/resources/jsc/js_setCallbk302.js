// var client_id = context.getVariable("verifyapikey.oa2_verifyAPIKey.client_id1");
var client_id = context.getVariable("thisMsg.client_id");
var wate = context.getVariable("thisMsg.wantState");
// var tgt_redir = context.getVariable("verifyapikey.oa2_verifyAPIKey.callback_uri");
// var tgt_redir = context.getVariable("verifyapikey.oa2_verifyAPIKey.redirection_uris");
var tgt_redir = context.getVariable("verifyapikey.oa2_verifyAPIKey.callback_uri");
var scope = context.getVariable("verifyapikey.oa2_verifyAPIKey.oauth_scope");
scope = "openid profile ace service event content push state group jp_api.is4 jp_api.user icoach email role adapt track stats parse meet plan";
var token = context.getVariable("thisMsg.access_token");

var redirect_uri = context.getVariable("request.queryparam.redirect_uri");
if ( typeof (redirect_uri) === "undefined" || redirect_uri === null || redirect_uri === "" )
    redirect_uri = context.getVariable("verifyapikey.oa2_verifyAPIKey.redirection_uris");

// ...Is the code in a queryparam ?
var code = context.getVariable("request.queryparam.code");
if ( typeof (code) === "undefined" || code === null || code === "") {
    // ...or have we already captured it?
    code = context.getVariable("thisMsg.auth_code");
    if ( typeof (code) === "undefined" || code === null || code === "") {
        print("\nNO CODE");
    }
}

if ( typeof (code) !== "undefined" && code !== null && code !== "")
    context.setVariable("response.header.Set-Cookie", "ac=" + code);
context.setVariable("response.status.code", "302");

// AL 1st, callback to LMS
loc = tgt_redir 
    + "?client_id=" + client_id 
    + "&response_type=code"
    + "&code=" + code
    + "&redirect_uri=" + redirect_uri 
    + "&state=" + wate
    + "&scope=" + scope
    ;
context.setVariable("thisMsg.nextLocation", loc);

// added for adaptive learning [AL]
var loc2 = context.getVariable("verifyapikey.oa2_verifyAPIKey.adaptLearn_uri");
if ( typeof (loc2) !== "undefined" && loc2 !== null && loc2 !== "" ) {
    loc2 = loc2
        + "?token=" + token
        + "&callback_uri=" + encodeURIComponent(loc) 
        ;
    context.setVariable("response.header.Location", loc); //loc2
} else 
    context.setVariable("response.header.Location", loc);


// // LMS 1st, callback to AL
// loc = tgt_redir 
//     + "?client_id=" + client_id 
//     + "&response_type=code"
//     + "&code=" + code
//     + "&redirect_uri=" + loc2
//     + "&state=" + wate
//     + "&scope=" + scope
//     ;

// var loc2 = "https://devdiu.cloud.cae.com"
//     + "/redirect?token=" + token
//     + "&callback_uri=" + encodeURIComponent(redirect_uri) 
//     ;

// End of for AL


// print ("\n[setCB302.3] "
//     + "\ntgt_redir= " + tgt_redir
//     + "\n\tLocation= " + loc 
//     + "\n\tLocation2= " + loc2 
//     + "\n\n"); 

